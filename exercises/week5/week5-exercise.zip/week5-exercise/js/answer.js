$(document).ready(function() {
    //Gets current year
    var currentYear = new Date().getFullYear();
    //Adds currentYear to the beginning of the selected HTML element
    $("#copyright").prepend(currentYear + " ");
    
    // Adds & removes "active" class to the navigation
    $("nav a").click(function(){
      $(".active").removeClass("active");
      $(this).addClass("active");
    });

//closes document ready
}); 

// Initialize the Smooth Scroll Plugin
// https://github.com/cferdinandi/smooth-scroll
smoothScroll.init();